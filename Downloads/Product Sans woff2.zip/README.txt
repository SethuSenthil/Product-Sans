Please read the font license: https://fonts.google.com/license/productsans
Hope you enjoy this font!

Source: https://Sethusenthil.github.io

____            __    __                  ____                   __    __           ___
/\  _`\         /\ \__/\ \                /\  _`\                /\ \__/\ \      __ /\_ \
\ \,\L\_\     __\ \ ,_\ \ \___   __  __   \ \,\L\_\     __    ___\ \ ,_\ \ \___ /\_\\//\ \
\/_\__ \   /'__`\ \ \/\ \  _ `\/\ \/\ \   \/_\__ \   /'__`\/' _ `\ \ \/\ \  _ `\/\ \ \ \ \
  /\ \L\ \/\  __/\ \ \_\ \ \ \ \ \ \_\ \    /\ \L\ \/\  __//\ \/\ \ \ \_\ \ \ \ \ \ \ \_\ \_
  \ `\____\ \____\\ \__\\ \_\ \_\ \____/    \ `\____\ \____\ \_\ \_\ \__\\ \_\ \_\ \_\/\____\
   \/_____/\/____/ \/__/ \/_/\/_/\/___/      \/_____/\/____/\/_/\/_/\/__/ \/_/\/_/\/_/\/____/

          --You may delete this file after installation to recover space in you device.                                                                               
